# BANK-LOAN-REPORT-OVERVIEW_Project
 This is a power bi project
